package Algorithm_Design_Quiz11;

public class Node {

    public Node next;
    public Node previous;
    public int level;
    public int profit;
    public int weight;
    public double bound;

    public Node(){
        next = null;
        previous = null;
    }


}
