package Algorithm_Design_Quiz13;

public class Node {
    public int[] steps;
    public Node next;

    public Node() {
        this.next = null;
    }
}
