package Algorithm_Design_Quiz9;

public class Quiz9 {

    public int numOfSubsets;
    public int n;
    public boolean[] vIndex;


    public Quiz9(int n){
        this.n = n;
        this.numOfSubsets = 0;
        vIndex = new boolean[n];
        for(int t = 0; t < n; t++){
            vIndex[t] = false;
        }
    }

    public void subset(int i){
        if(i == this.n){
            boolean isNull = true;
            for(int t = 0; t < this.n; t++){
                if(vIndex[t]){
                    System.out.print((t+1) + " ");
                    isNull = false;
                }
            }
            numOfSubsets++;
            if(isNull){
                System.out.println("null subset");
            }
            System.out.println();
        }
        else{
            vIndex[i] = true;
            subset(i + 1);
            vIndex[i] = false;
            subset(i + 1);
        }
    }

    public static void main(String args[]){
        Quiz9 a = new Quiz9(3);
        System.out.println("n = " + a.n + ", the set is {1, ..., " + a.n + "}.");
        System.out.println("Subsets:");
        a.subset(0);
        System.out.println("This set has " + a.numOfSubsets + " subsets.");
        a.numOfSubsets = 0;
        System.out.println();
        System.out.println("--------------------------------------------------------");

        a = new Quiz9(5);
        System.out.println("n = " + a.n + ", the set is {1, ..., " + a.n + "}.");
        System.out.println("Subsets:");
        a.subset(0);
        System.out.println("This set has " + a.numOfSubsets + " subsets.");
        a.numOfSubsets = 0;
        System.out.println();
        System.out.println("--------------------------------------------------------");

        a = new Quiz9(7);
        System.out.println("n = " + a.n + ", the set is {1, ..., " + a.n + "}.");
        System.out.println("Subsets:");
        a.subset(0);
        System.out.println("This set has " + a.numOfSubsets + " subsets.");
        a.numOfSubsets = 0;
    }
}
